-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3307
-- Üretim Zamanı: 05 Oca 2026, 03:24:34
-- Sunucu sürümü: 10.4.32-MariaDB
-- PHP Sürümü: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `pharmacy`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `medicines`
--

CREATE TABLE `medicines` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `stock` int(11) DEFAULT 0,
  `price` decimal(10,2) DEFAULT 0.00,
  `expiration_date` date DEFAULT NULL,
  `supplier` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `medicines`
--

INSERT INTO `medicines` (`id`, `name`, `stock`, `price`, `expiration_date`, `supplier`, `created_at`, `updated_at`) VALUES
(1, 'Parol 500mg', 150, 25.50, '2026-12-31', 'Eczacıbaşı', '2025-12-22 20:03:27', '2025-12-22 20:03:27'),
(2, 'Aspirin 100mg', 200, 15.75, '2026-06-30', 'Bayer', '2025-12-22 20:03:27', '2025-12-22 20:03:27'),
(3, 'Majezik', 100, 85.00, '2025-08-15', 'Sanovel', '2025-12-22 20:03:27', '2025-12-26 07:13:57'),
(4, 'Augmentin 1000mg', 50, 120.00, '2025-09-30', 'GSK', '2025-12-22 20:03:27', '2025-12-22 20:03:27'),
(7, 'Parol 500 Mg Tablet', 150, 35.50, '2026-05-20', 'Atabay Kimya', '2025-12-23 14:09:08', '2025-12-23 14:09:08'),
(8, 'Majezik 100 Mg Film Tablet', 85, 92.00, '2025-11-15', 'Sanovel', '2025-12-23 14:09:08', '2025-12-23 14:09:08'),
(9, 'Aspirin 100 Mg', 200, 45.00, '2026-02-10', 'Bayer', '2025-12-23 14:09:08', '2025-12-23 14:09:08'),
(11, 'Augmentin 1000 Mg', 40, 145.00, '2025-06-01', 'GlaxoSmithKline', '2025-12-23 14:09:08', '2025-12-23 14:09:08'),
(12, 'Dolorex 50 Mg Draje', 95, 55.25, '2026-08-12', 'Abdi İbrahim', '2025-12-23 14:09:08', '2025-12-23 14:09:08'),
(13, 'Theraflu Forte', 60, 85.50, '2025-12-30', 'Novartis', '2025-12-23 14:09:08', '2025-12-23 14:09:08'),
(14, 'Tylolhot Poşet', 150, 120.00, '2027-01-15', 'Nobel İlaç', '2025-12-23 14:09:08', '2025-12-23 14:09:08'),
(15, 'Vermidon 500 Mg', 180, 25.00, '2026-04-20', 'Kozmed', '2025-12-23 14:09:08', '2025-12-23 14:09:08'),
(16, 'Apranax Fort 550 Mg', 70, 110.00, '2025-07-25', 'Abdi İbrahim', '2025-12-23 14:09:08', '2025-12-23 14:09:08'),
(17, 'Nurofen Cold & Flu', 110, 135.00, '2026-10-05', 'Reckitt Benckiser', '2025-12-23 14:09:08', '2025-12-23 14:09:08'),
(18, 'Benical Cold', 90, 95.00, '2025-08-18', 'Bayer', '2025-12-23 14:09:08', '2025-12-23 14:09:08'),
(19, 'Cataflam 50 Mg', 65, 78.50, '2026-03-14', 'Novartis', '2025-12-23 14:09:08', '2025-12-23 14:09:08'),
(20, 'Dikloron 75 Mg Ampul', 50, 42.00, '2025-05-30', 'Deva Holding', '2025-12-23 14:09:08', '2025-12-23 14:09:08'),
(21, 'Lansor 30 Mg Kapsül', 130, 88.00, '2027-02-28', 'Sanovel', '2025-12-23 14:09:08', '2025-12-23 14:09:08'),
(22, 'Nexium 40 Mg', 45, 160.00, '2026-09-10', 'AstraZeneca', '2025-12-23 14:09:08', '2025-12-23 14:09:08'),
(23, 'Gaviscon Şurup', 100, 105.00, '2025-12-01', 'Reckitt Benckiser', '2025-12-23 14:09:08', '2025-12-23 14:09:08'),
(24, 'Voltaren Emulgel', 80, 115.00, '2026-06-20', 'Novartis', '2025-12-23 14:09:08', '2025-12-23 14:09:08'),
(25, 'Bepanthen Krem', 140, 150.00, '2027-03-15', 'Bayer', '2025-12-23 14:09:08', '2025-12-23 14:09:08'),
(26, 'Supradyn All Day', 60, 250.00, '2026-11-25', 'Bayer', '2025-12-23 14:09:08', '2025-12-23 14:09:08');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `sender_name` varchar(100) DEFAULT NULL,
  `sender_email` varchar(100) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `messages`
--

INSERT INTO `messages` (`id`, `sender_name`, `sender_email`, `message`, `sent_at`) VALUES
(1, 'ırmak', 'irmak@gmail.com', 'cok iyi', '2025-12-23 13:38:44'),
(2, 'dfd', 'dfdf@gmail.com', 'dfdfs', '2025-12-23 14:26:21'),
(3, 'Irmak', 'irmakarikogullarindan@gmail.com', 'çok sağolun', '2025-12-23 17:28:55'),
(4, 'Irmak', 'irmak@gmail.com', 'çok teşekkürler', '2025-12-25 21:14:50'),
(5, 'ırmak', 'irmak@gmail.com', 'cok tesekkurler', '2025-12-26 06:46:05'),
(6, 'öykü', 'oyku@gmail.com', 'çok teşekkürler', '2025-12-26 17:34:54');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `username`, `password_hash`, `email`, `created_at`) VALUES
(1, 'admin', '$2y$10$uWGkC1FurvgEZVxnuWrV9uJ7yR4aqZZRtS130KPiJeclTyi9CM/Hu', 'admin@medicare.com', '2025-12-22 20:03:27');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `medicines`
--
ALTER TABLE `medicines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_name` (`name`),
  ADD KEY `idx_expiry` (`expiration_date`);

--
-- Tablo için indeksler `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `idx_username` (`username`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `medicines`
--
ALTER TABLE `medicines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- Tablo için AUTO_INCREMENT değeri `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
