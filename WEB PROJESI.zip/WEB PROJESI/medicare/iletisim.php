<?php
session_start();
require_once 'db.php';

$msg = '';
$msg_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = isset($_POST['name']) ? htmlspecialchars(trim($_POST['name'])) : '';
    $email = isset($_POST['email']) ? htmlspecialchars(trim($_POST['email'])) : '';
    $message = isset($_POST['message']) ? htmlspecialchars(trim($_POST['message'])) : '';


    if (!empty($name) && !empty($email) && !empty($message)) {
        try {


            $stmt = $pdo->prepare("INSERT INTO messages (sender_name, sender_email, message) VALUES (?, ?, ?)");
            $stmt->execute([$name, $email, $message]);

            $msg = "Teşekkürler, $name! Mesajınız başarıyla iletildi.";
            $msg_type = "success";
        } catch (PDOException $e) {
            $msg = "Mesaj gönderilirken bir hata oluştu: " . $e->getMessage();
            $msg_type = "error";
        }
    } else {
        $msg = "Lütfen tüm alanları doldurunuz.";
        $msg_type = "error";
    }
}
?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>İletişim - Medicare</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body class="bg-gray-50 font-sans flex flex-col min-h-screen">

    <nav class="bg-gradient-to-r from-green-600 to-blue-600 p-6 shadow-lg">
        <div class="container mx-auto flex items-center justify-between">
            <a href="index.php" class="text-4xl font-extrabold text-white hover:text-yellow-300 transition duration-300">
                Medicare
            </a>

            <div class="hidden md:flex space-x-12 items-center">
                <a href="index.php" class="text-white text-xl font-bold hover:text-yellow-300">Ana Sayfa</a>
                <a href="hakkimizda.php" class="text-white text-xl font-bold hover:text-yellow-300">Hakkımızda</a>

                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="stok.php" class="text-white text-xl font-bold hover:text-yellow-300">Stok Listesi</a>
                    <a href="cikis.php" class="text-red-200 text-xl font-bold">Çıkış</a>
                <?php else: ?>
                    <a href="giris.php" class="text-white text-xl font-bold hover:text-yellow-300">Giriş</a>
                <?php endif; ?>

                <a href="iletisim.php" class="text-yellow-300 text-xl font-bold">İletişim</a>
            </div>
        </div>
    </nav>

    <main class="container mx-auto mt-10 px-4 flex-grow mb-10">

        <div class="text-center mb-10">
            <h2 class="text-3xl font-bold text-gray-800">Bizimle İletişime Geçin</h2>
            <p class="text-gray-600 mt-2">Sorularınız, önerileriniz veya şikayetleriniz için aşağıdaki formu doldurabilirsiniz.</p>
        </div>

        <div class="grid md:grid-cols-2 gap-10 max-w-6xl mx-auto">

            <div class="space-y-8">
                <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-blue-500">
                    <h3 class="text-xl font-bold text-gray-800 mb-4">İletişim Bilgileri</h3>
                    <div class="space-y-4">
                        <div class="flex items-center">
                            <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 mr-4">
                                <i class="fas fa-map-marker-alt"></i>
                            </div>
                            <p class="text-gray-600">Atatürk Cad. No:123, Şişli/İstanbul</p>
                        </div>
                        <div class="flex items-center">
                            <div class="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-600 mr-4">
                                <i class="fas fa-phone-alt"></i>
                            </div>
                            <p class="text-gray-600">+90 (212) 555 00 00</p>
                        </div>
                        <div class="flex items-center">
                            <div class="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center text-yellow-600 mr-4">
                                <i class="fas fa-envelope"></i>
                            </div>
                            <p class="text-gray-600">info@medicare.com</p>
                        </div>
                    </div>
                </div>

                <section class="mt-10">
                    <h3 class="text-xl font-semibold text-red-700 mb-4">Hizmet Verdiğimiz Eczaneler</h3>
                    <div class="rounded-lg overflow-hidden border-2 border-red-100 shadow-md">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d24077.05082788481!2d28.770352080165623!3d41.033320518929976!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1seczaneler!5e0!3m2!1str!2str!4v1766426637186!5m2!1str!2str" width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </section>
            </div>

            <div class="bg-white p-8 rounded-xl shadow-2xl">
                <h3 class="text-2xl font-bold text-gray-800 mb-6 border-b pb-2">Mesaj Gönder</h3>

                <?php if (!empty($msg)): ?>
                    <div class="p-4 mb-6 rounded-lg <?php echo $msg_type == 'success' ? 'bg-green-100 text-green-700 border border-green-200' : 'bg-red-100 text-red-700 border border-red-200'; ?>">
                        <?php echo $msg; ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="iletisim.php">
                    <div class="mb-6">
                        <label for="name" class="block text-gray-700 font-semibold mb-2">Adınız Soyadınız</label>
                        <div class="relative">
                            <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
                                <i class="fas fa-user"></i>
                            </span>
                            <input type="text" id="name" name="name" required
                                class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition duration-200"
                                placeholder="Örn: Ahmet Yılmaz">
                        </div>
                    </div>

                    <div class="mb-6">
                        <label for="email" class="block text-gray-700 font-semibold mb-2">E-posta Adresiniz</label>
                        <div class="relative">
                            <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
                                <i class="fas fa-envelope"></i>
                            </span>
                            <input type="email" id="email" name="email" required
                                class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition duration-200"
                                placeholder="Örn: ahmet@mail.com">
                        </div>
                    </div>

                    <div class="mb-6">
                        <label for="message" class="block text-gray-700 font-semibold mb-2">Mesajınız</label>
                        <div class="relative">
                            <textarea id="message" name="message" rows="5" required
                                class="w-full p-4 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition duration-200"
                                placeholder="Mesajınızı buraya yazınız..."></textarea>
                        </div>
                    </div>

                    <button type="submit" class="w-full bg-gradient-to-r from-blue-600 to-indigo-700 text-white font-bold py-3 px-4 rounded-lg hover:from-blue-700 hover:to-indigo-800 transition transform hover:-translate-y-1 shadow-lg">
                        <i class="fas fa-paper-plane mr-2"></i> Gönder
                    </button>
                </form>
            </div>

        </div>
    </main>

    <footer class="bg-gray-800 text-white py-8 text-center mt-auto">
        <p class="text-lg">&copy; 2025 Medicare - Tüm Hakları Saklıdır.</p>
    </footer>

    <script src="a.js"></script>
</body>

</html>