<?php
session_start();
require_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST['username'];
    $pass = $_POST['password'];


    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$user]);
    $db_user = $stmt->fetch();


    if ($db_user && password_verify($pass, $db_user['password_hash'])) {

        $_SESSION['user_id'] = $db_user['id'];
        $_SESSION['username'] = $db_user['username'];



        header("Location: stok.php");
        exit();
        
    } else {
        $error = "Hatalı kullanıcı adı veya şifre!";
    }
}
?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <title>Giriş - Medicare</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="style.css">
</head>

<body class="bg-gray-100 flex items-center justify-center h-screen">
    <div class="bg-white p-8 rounded-lg shadow-lg w-96 border-t-4 border-blue-600">
        <h2 class="text-2xl font-bold mb-6 text-center">Yönetici Girişi</h2>

        <?php if (isset($error)) echo "<p class='text-red-500 mb-4 font-bold'>$error</p>"; ?>

        <form method="POST">
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-1">Kullanıcı Adı</label>
                <input type="text" name="username" class="w-full border p-2 rounded focus:ring-2 focus:ring-blue-500 outline-none" required>
            </div>
            <div class="mb-6">
                <label class="block text-sm font-medium text-gray-700 mb-1">Şifre</label>
                <input type="password" name="password" class="w-full border p-2 rounded focus:ring-2 focus:ring-blue-500 outline-none" required>
            </div>
            <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition font-bold">Giriş Yap</button>
        </form>

        <div class="mt-4 text-center">
            <a href="index.php" class="text-sm text-gray-500 hover:underline">← Ana Sayfaya Dön</a>
        </div>
    </div>
</body>

</html>