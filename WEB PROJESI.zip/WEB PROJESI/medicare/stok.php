<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: giris.php");
    exit();
}

$message = "";

// --- 1. İŞLEM: İLAÇ EKLEME ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    $name = $_POST['name'];
    $stock = $_POST['stock'];
    $price = $_POST['price'];
    $expiration = $_POST['expiration'];
    $supplier = $_POST['supplier'];

    if (!empty($name) && !empty($stock)) {
        try {
            $sql = "INSERT INTO medicines (name, stock, price, expiration_date, supplier) VALUES (?, ?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$name, $stock, $price, $expiration, $supplier]);
            $message = "✅ İlaç başarıyla eklendi!";
        } catch (PDOException $e) {
            $message = "❌ Hata: " . $e->getMessage();
        }
    }
}

// --- 2. İŞLEM: GÜNCELLEME (UPDATE) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'update') {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $stock = $_POST['stock'];
    $price = $_POST['price'];

    try {
        $sql = "UPDATE medicines SET name=?, stock=?, price=? WHERE id=?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$name, $stock, $price, $id]);


        header("Location: stok.php");
        exit();
    } catch (PDOException $e) {
        $message = "❌ Güncelleme Hatası: " . $e->getMessage();
    }
}

// --- 3. İŞLEM: SİLME ---
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    try {
        $stmt = $pdo->prepare("DELETE FROM medicines WHERE id = ?");
        $stmt->execute([$id]);
        header("Location: stok.php");
        exit();
    } catch (PDOException $e) {
        $message = "Silme Hatası: " . $e->getMessage();
    }
}

// --- 4. İŞLEM: LİSTELEME ---
try {
    $stmt = $pdo->query("SELECT * FROM medicines ORDER BY id DESC");
    $medicines = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Veri çekme hatası: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <title>Stok Paneli - Medicare</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body class="bg-gray-100 font-sans">

    <nav class="bg-gradient-to-r from-green-600 to-blue-600 p-6 shadow-lg">
        <div class="container mx-auto flex items-center justify-between">
            <a href="index.php" class="text-4xl font-extrabold text-white hover:text-yellow-300 transition duration-300">
                Medicare
            </a>

            <div class="hidden md:flex space-x-12 items-center">
                <a href="index.php" class="text-white text-xl font-bold hover:text-yellow-300">Ana Sayfa</a>
                <a href="hakkimizda.php" class="text-white text-xl font-bold hover:text-yellow-300">Hakkımızda</a>
                <a href="stok.php" class="text-yellow-300 text-xl font-bold border-b-2 border-yellow-300">Stok Listesi</a>
                <a href="cikis.php" class="text-red-200 text-xl font-bold hover:text-red-100">Çıkış</a>
                <a href="iletisim.php" class="text-white text-xl font-bold hover:text-yellow-300">İletişim</a>
            </div>
        </div>
    </nav>

    <div class="container mx-auto mt-10 p-4">

        <div class="grid md:grid-cols-3 gap-8">

            <div class="md:col-span-1 bg-white p-6 rounded-xl shadow-lg h-fit">
                <h3 class="text-xl font-bold text-gray-800 mb-4 border-b pb-2"><i class="fas fa-plus-circle text-green-600"></i> Yeni İlaç Ekle</h3>

                <?php if ($message): ?>
                    <div class="p-3 mb-4 rounded bg-blue-100 text-blue-800 text-sm font-bold"><?= $message ?></div>
                <?php endif; ?>

                <form method="POST" action="stok.php">
                    <input type="hidden" name="action" value="add">

                    <div class="mb-3">
                        <label class="block text-sm font-bold text-gray-700">İlaç Adı</label>
                        <input type="text" name="name" required class="w-full border p-2 rounded focus:ring-2 focus:ring-blue-400 outline-none" placeholder="Örn: Parol">
                    </div>

                    <div class="grid grid-cols-2 gap-3 mb-3">
                        <div>
                            <label class="block text-sm font-bold text-gray-700">Stok Adedi</label>
                            <input type="number" name="stock" required class="w-full border p-2 rounded focus:ring-2 focus:ring-blue-400 outline-none">
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-gray-700">Fiyat (₺)</label>
                            <input type="number" step="0.01" name="price" required class="w-full border p-2 rounded focus:ring-2 focus:ring-blue-400 outline-none">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="block text-sm font-bold text-gray-700">Son Kullanma Tarihi</label>
                        <input type="date" name="expiration" class="w-full border p-2 rounded focus:ring-2 focus:ring-blue-400 outline-none">
                    </div>

                    <div class="mb-4">
                        <label class="block text-sm font-bold text-gray-700">Tedarikçi Firma</label>
                        <input type="text" name="supplier" class="w-full border p-2 rounded focus:ring-2 focus:ring-blue-400 outline-none" placeholder="Örn: Eczacıbaşı">
                    </div>

                    <button type="submit" class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 rounded transition shadow-md">
                        Kaydet
                    </button>
                </form>
            </div>

            <div class="md:col-span-2 bg-white p-6 rounded-xl shadow-lg">
                <div class="flex justify-between items-center mb-4 border-b pb-2">
                    <h3 class="text-xl font-bold text-gray-800"><i class="fas fa-list text-blue-600"></i> Güncel Stok Listesi</h3>
                    <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-bold">Toplam: <?= count($medicines) ?> Kayıt</span>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-gray-100 text-gray-700 uppercase text-sm leading-normal">
                                <th class="py-3 px-4 rounded-l-lg">ID</th>
                                <th class="py-3 px-4">İlaç Adı</th>
                                <th class="py-3 px-4">Stok</th>
                                <th class="py-3 px-4">Fiyat</th>
                                <th class="py-3 px-4">SKT</th>
                                <th class="py-3 px-4 rounded-r-lg text-center">İşlem</th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-600 text-sm font-light">
                            
                            <?php foreach ($medicines as $ilac): ?>

                                <?php
                                    $editMode = (isset($_GET['edit']) && $_GET['edit'] == $ilac['id']);

                                    $expDate = new DateTime($ilac['expiration_date']);
                                    $today = new DateTime();
                                    $isExpired = $expDate < $today;
                                ?>

                                <tr class="border-b border-gray-200 hover:bg-gray-50 transition">

                                    <?php if ($editMode): ?>
                                        <td class="py-3 px-4 font-bold text-blue-600">
                                            #<?= $ilac['id'] ?>
                                            <form id="updateForm-<?= $ilac['id'] ?>" method="POST" action="stok.php">
                                                <input type="hidden" name="action" value="update">
                                                <input type="hidden" name="id" value="<?= $ilac['id'] ?>">
                                            </form>
                                        </td>

                                        <td class="py-3 px-4">
                                            <input type="text" name="name" form="updateForm-<?= $ilac['id'] ?>"
                                                value="<?= htmlspecialchars($ilac['name']) ?>"
                                                class="border border-blue-400 rounded px-2 py-1 w-full text-black font-bold focus:outline-none focus:ring-2 focus:ring-blue-500">
                                        </td>

                                        <td class="py-3 px-4">
                                            <input type="number" name="stock" form="updateForm-<?= $ilac['id'] ?>"
                                                value="<?= $ilac['stock'] ?>"
                                                class="border border-blue-400 rounded px-2 py-1 w-20 text-black">
                                        </td>

                                        <td class="py-3 px-4">
                                            <input type="number" step="0.01" name="price" form="updateForm-<?= $ilac['id'] ?>"
                                                value="<?= $ilac['price'] ?>"
                                                class="border border-blue-400 rounded px-2 py-1 w-20 text-black">
                                        </td>

                                        <td class="py-3 px-4 text-gray-400 cursor-not-allowed">
                                            <?= $ilac['expiration_date'] ?>
                                        </td>

                                        <td class="py-3 px-4 text-center flex space-x-2 justify-center">
                                            <button type="submit" form="updateForm-<?= $ilac['id'] ?>"
                                                class="bg-green-500 hover:bg-green-600 text-white p-2 rounded shadow transition" title="Değişiklikleri Kaydet">
                                                <i class="fas fa-save"></i>
                                            </button>
                                            <a href="stok.php" class="bg-gray-500 hover:bg-gray-600 text-white p-2 rounded shadow transition" title="İptal">
                                                <i class="fas fa-times"></i>
                                            </a>
                                        </td>

                                    <?php else: ?>
                                        <td class="py-3 px-4 font-bold text-blue-600">#<?= $ilac['id'] ?></td>

                                        <td class="py-3 px-4 text-gray-800 font-bold">
                                            <?= htmlspecialchars($ilac['name']) ?>
                                        </td>

                                        <td class="py-3 px-4">
                                            <i><?= $ilac['stock'] ?> Adet</i>
                                        </td>

                                        <td class="py-3 px-4">
                                            <u><?= $ilac['price'] ?> ₺</u>
                                        </td>

                                        <td class="py-3 px-4 align-bottom">
                                            <?php if ($isExpired): ?>
                                                <span class="text-red-500 font-bold" title="Tarihi Geçmiş!">
                                                    <s><?= $ilac['expiration_date'] ?></s> (SKT)
                                                </span>
                                            <?php else: ?>
                                                <span class="text-green-600"><?= $ilac['expiration_date'] ?></span>
                                            <?php endif; ?>
                                        </td>

                                        <td class="py-3 px-4 text-center">
                                            <a href="stok.php?edit=<?= $ilac['id'] ?>" class="bg-yellow-400 hover:bg-yellow-500 text-white p-2 rounded-full shadow transition mr-2" title="Düzenle">
                                                <i class="fas fa-pen"></i>
                                            </a>
                                            <a href="stok.php?delete=<?= $ilac['id'] ?>" onclick="return confirm('Bu ilacı silmek istediğine emin misin?')" class="bg-red-500 hover:bg-red-600 text-white p-2 rounded-full shadow transition" title="Sil">
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>

                            <?php if (count($medicines) == 0): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4">Kayıtlı ilaç bulunamadı.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <<footer class="bg-gray-800 text-white py-8 text-center mt-auto">
        <p class="text-lg">&copy; 2025 Medicare - Tüm Hakları Saklıdır.</p>
        </footer>

</body>

</html>