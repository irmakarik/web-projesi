<?php
session_start();
?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hakkımızda - Medicare</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body class="bg-gray-50 font-sans">

    <nav class="bg-gradient-to-r from-green-600 to-blue-600 p-6 shadow-lg">
        <div class="container mx-auto flex items-center justify-between">
            <a href="index.php" class="text-4xl font-extrabold text-white hover:text-yellow-300 transition duration-300">
                Medicare
            </a>

            <div class="hidden md:flex space-x-12 items-center">
                <a href="index.php" class="text-white text-xl font-bold hover:text-yellow-300">Ana Sayfa</a>
                <a href="hakkimizda.php" class="text-white text-xl font-bold hover:text-yellow-300">Hakkımızda</a>

                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="stok.php" class="text-white text-xl font-bold hover:text-yellow-300">Stok Listesi</a>
                    <a href="cikis.php" class="text-red-200 text-xl font-bold">Çıkış</a>
                <?php else: ?>
                    <a href="giris.php" class="text-white text-xl font-bold hover:text-yellow-300">Giriş</a>
                <?php endif; ?>

                <a href="iletisim.php" class="text-white text-xl font-bold hover:text-yellow-300">İletişim</a>
            </div>
        </div>
    </nav>

    <main class="container mx-auto mt-10 p-8 bg-white shadow-lg rounded-xl max-w-4xl">

        <h2 class="text-3xl font-bold text-indigo-900 mb-2">Sitemiz Hakkında</h2>
        <hr class="mb-6 border-t-2 border-indigo-100">
        <div class="prose max-w-none text-gray-700 space-y-6">
            <section>
                <h3 class="text-xl font-semibold text-green-700">Misyonumuz</h3>
                <p>Eczanelerin ilaç ve ürün stoklarını dijital ortamda kolayca takip edebilmelerini sağlayan, kullanıcı dostu ve güvenilir bir stok yönetim sistemi sunmak. Misyonumuz, eczanelerin stok kayıplarını önlemesine, eksik ürünleri zamanında fark etmesine ve iş süreçlerini daha verimli hale getirmesine katkıda bulunmaktır.</p>
            </section>

            <section>
                <h3 class="text-xl font-semibold text-green-700">Biz Kimiz</h3>
                <p>Biz, eczanelerin günlük stok yönetimi süreçlerinde karşılaştığı zorlukları anlayan ve bu sorunlara yazılımsal çözümler üretmeyi hedefleyen bir ekip tarafından geliştirilen bir sistemiz. Amacımız, karmaşık stok işlemlerini sadeleştirerek eczaneler için kolay, anlaşılır ve sürdürülebilir bir yönetim ortamı sunmaktır.</p>
            </section>

            <section>
                <h3 class="text-xl font-semibold text-green-700">Kalite Güvencesi</h3>
                <p>Sistemimiz, veri güvenliği ve doğruluğu ön planda tutularak geliştirilmiştir. Stok bilgilerinin güvenli şekilde saklanması, düzenli güncellenmesi ve doğru raporlanması için gerekli yazılım standartlarına uygun olarak tasarlanmıştır.</p>
            </section>

            <div class="grid md:grid-cols-2 gap-8">
                <div>
                    <p class="font-bold mb-2">Taahhütlerimiz:</p>
                    <ul class="list-disc ml-5 space-y-1 text-gray-600">
                        <li>Eczaneler için pratik ve kullanıcı dostu arayüz</li>
                        <li>Stokların anlık ve doğru takibi</li>
                        <li>Eksik veya kritik stoklar için kontrol imkânı</li>
                        <li>Zaman ve iş gücü tasarrufu sağlayan sistem yapısı</li>
                        <li>Sürekli geliştirilebilir ve ölçeklenebilir altyapı</li>
                    </ul>
                </div>
                <div>
                    <p class="font-bold mb-2">Sistemimizin Sunduğu Özellikler:</p>
                    <ul class="list-disc ml-5 space-y-1 text-gray-600">
                        <li><strong>Stok Takibi:</strong> Ürünlerin giriş-çıkışlarını kolayca yönetin</li>
                        <li><strong>Ürün Yönetimi:</strong> İlaç ve ürün bilgilerini düzenleyin</li>
                        <li><strong>Kontrol Mekanizması:</strong> Stok durumlarını anlık görüntüleyin</li>
                        <li><strong>Dijital Yönetim:</strong> Manuel işlemleri azaltarak hata payını düşürün</li>
                        <li><strong>Raporlama:</strong> Stok verilerini düzenli ve anlaşılır şekilde inceleyin</li>
                    </ul>
                </div>
            </div>

            <section class="mt-10">
                <h3 class="text-xl font-semibold text-red-700 mb-4">Hizmet Verdiğimiz Eczaneler</h3>
                <div class="rounded-lg overflow-hidden border-2 border-red-100 shadow-md">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d24077.05082788481!2d28.770352080165623!3d41.033320518929976!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1seczaneler!5e0!3m2!1str!2str!4v1766426637186!5m2!1str!2str" width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </section>

            <section class="mt-10 border-t pt-8">
                <h3 class="text-xl font-bold text-indigo-700 mb-2">
                    <i class="fas fa-layer-group"></i> ÇOK YAKINDA! Akıllı Raf Konumlandırma Modülü
                </h3>

                <p class="text-gray-600 mb-6 text-sm">
                    Medicare sistemi, sadece stok adetlerini değil, yakında ilaçların fiziksel konumlarını da yönetmenize olanak tanıyacak.
                    <strong>"Görsel Raf Yönetimi"</strong> özelliği sayesinde eczanenizin krokisini sisteme yükleyebilecek, hangi ilacın hangi dolapta olduğunu görsel arayüz üzerinden takip edebileceksiniz!
                    <br><br>
                </p>

                <div class="flex justify-center">
                    <svg width="100%" height="180" class="max-w-md border-2 border-dashed border-indigo-300 rounded-lg bg-indigo-50" usemap="#pharmmap">
                        <rect width="100%" height="100%" fill="transparent" />
                        <text x="50%" y="30" font-size="16" font-weight="bold" fill="#3730a3" text-anchor="middle">Sistem Arayüzü: Raf Görünümü</text>

                        <rect x="10" y="50" width="45%" height="120" fill="#c7d2fe" stroke="#4f46e5" stroke-width="2" />
                        <text x="25%" y="110" font-size="14" font-weight="bold" fill="#312e81" text-anchor="middle">A Dolabı (Tıkla)</text>

                        <rect x="55%" y="50" width="45%" height="120" fill="#a7f3d0" stroke="#059669" stroke-width="2" />
                        <text x="75%" y="110" font-size="14" font-weight="bold" fill="#064e3b" text-anchor="middle">B Dolabı (Tıkla)</text>
                    </svg>
                </div>

                <map name="pharmmap">
                    <area shape="rect" coords="10,50,225,170" href="stok.php?bolum=A" alt="A Dolabı Stokları">
                    <area shape="rect" coords="225,50,450,170" href="stok.php?bolum=B" alt="B Dolabı Stokları">
                </map>
                
            </section>
        </div>
    </main>

    <footer class="bg-gray-800 text-white mt-12 py-8 text-center text-sm">
        <p>&copy; 2025 Medicare - Tüm hakları saklıdır.</p>
    </footer>

    <script src="a.js"></script>
</body>

</html>