<?php session_start(); ?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medicare - Eczane Stok Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body class="font-sans bg-white text-gray-900">

    <nav class="bg-gradient-to-r from-green-600 to-blue-600 p-6 shadow-lg">
        <div class="container mx-auto flex items-center justify-between">
            <a href="index.php" class="text-4xl font-extrabold text-white hover:text-yellow-300 transition duration-300">
                Medicare
            </a>

            <div class="hidden md:flex space-x-12 items-center">
                <a href="index.php" class="text-white text-xl font-bold hover:text-yellow-300">Ana Sayfa</a>
                <a href="hakkimizda.php" class="text-white text-xl font-bold hover:text-yellow-300">Hakkımızda</a>

                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="stok.php" class="text-white text-xl font-bold hover:text-yellow-300">Stok Listesi</a>
                    <a href="cikis.php" class="text-red-200 text-xl font-bold">Çıkış</a>
                <?php else: ?>
                    <a href="giris.php" class="text-white text-xl font-bold hover:text-yellow-300">Giriş</a>
                <?php endif; ?>

                <a href="iletisim.php" class="text-white text-xl font-bold hover:text-yellow-300">İletişim</a>
            </div>
        </div>
    </nav>

    <div class="bg-indigo-500 text-white py-2">
        <div class="container mx-auto flex items-center">
            <span class="bg-red-600 text-xs font-bold px-2 py-1 rounded mr-3">DUYURU</span>
            <marquee behavior="scroll" direction="left" class="text-sm font-medium">
                📢 Yıl sonu stok sayımları başlamıştır! Lütfen ilaç girişlerini eksiksiz yapınız. | 💊 Yeni ağrı kesici grubu stoklarımıza eklenmiştir.
            </marquee>
        </div>
    </div>

    <div class="container mx-auto mt-6 px-4 max-w-7xl">
        <div class="grid md:grid-cols-4 gap-6 h-[500px]">

            <div class="md:col-span-3 relative h-full rounded-3xl overflow-hidden shadow-2xl group">
                <div class="absolute left-0 top-0 bottom-0 w-24 bg-gradient-to-r from-black/40 to-transparent z-20 pointer-events-none"></div>
                <div class="absolute right-0 top-0 bottom-0 w-24 bg-gradient-to-l from-black/40 to-transparent z-20 pointer-events-none"></div>

                <div id="slider-container" class="relative w-full h-full bg-gray-900">

                    <div class="slide active">
                        <img src="img/slide1.jpg" alt="Sağlık 1" class="object-cover w-full h-full opacity-90">
                        <div class="absolute inset-0 flex flex-col items-center justify-center text-center px-12 z-30">
                            <h2 class="text-white text-5xl font-black mb-6 drop-shadow-lg tracking-tight">7/24 Kesintisiz Hizmet</h2>
                            <?php if (!isset($_SESSION['user_id'])): ?>
                                <a href="giris.php" class="px-8 py-3 bg-indigo-600 text-white rounded-full text-lg font-bold hover:bg-indigo-700 shadow-xl transition transform hover:scale-105 border-2 border-transparent hover:border-indigo-400">
                                    Giriş Yap
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="slide">
                        <img src="img/slide2.jpg" alt="Sağlık 2" class="object-cover w-full h-full opacity-90">
                        <div class="absolute inset-0 flex flex-col items-center justify-center text-center px-12 z-30">
                            <h2 class="text-white text-5xl font-black mb-6 drop-shadow-lg tracking-tight">Stoklarınız Güvende</h2>
                            <a href="<?php echo isset($_SESSION['user_id']) ? 'stok.php' : 'giris.php'; ?>"
                                class="px-8 py-3 bg-white text-indigo-900 rounded-full text-lg font-bold shadow-xl transition transform hover:scale-105 hover:bg-gray-100">
                                <?php echo isset($_SESSION['user_id']) ? 'Stok Listesine Git' : 'Stoklar'; ?>
                            </a>
                        </div>
                    </div>

                    <div class="slide">
                        <img src="img/slide3.jpg" alt="Sağlık 3" class="object-cover w-full h-full opacity-90">
                        <div class="absolute inset-0 flex flex-col items-center justify-center text-center px-12 z-30">
                            <h2 class="text-white text-5xl font-black mb-6 drop-shadow-lg tracking-tight">Tam Kontrol Sağlayın</h2>
                            <a href="iletisim.php" class="px-8 py-3 bg-yellow-400 text-indigo-900 rounded-full text-lg font-bold hover:bg-yellow-500 shadow-xl transition transform hover:scale-105">
                                Bize Ulaşın
                            </a>
                        </div>
                    </div>

                </div>
            </div>

            <div class="md:col-span-1 h-full hidden md:block">
                <div class="relative w-full h-full rounded-3xl overflow-hidden shadow-2xl border border-gray-200 group">
                    <span class="absolute top-3 right-3 bg-white/90 text-red-600 text-[10px] font-bold px-2 py-1 rounded shadow-sm z-10 tracking-widest border border-red-100 animate-pulse">
                        SPONSORLU
                    </span>
                    <a href="https://www.burgerking.com.tr" target="_blank" class="block w-full h-full relative">
                        <img src="https://placehold.co/300x600/bf281d/ffffff?text=ACIKTIN+MI%3F%0A%0AWHOPPER%0AFIRSATI%0A%0A%2550+INDIRIM&font=oswald"
                            alt="Burger King Dikey Reklam"
                            class="w-full h-full object-cover transition duration-700 transform group-hover:scale-105">
                        <div class="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6 text-center">
                            <span class="inline-block bg-yellow-500 text-red-900 font-extrabold px-6 py-2 rounded-full shadow-lg hover:bg-yellow-400 transition">
                                <i class="fas fa-hamburger mr-2"></i> SİPARİŞ VER
                            </span>
                        </div>
                    </a>
                </div>
            </div>

        </div>
    </div>

    <section class="container mx-auto px-4 py-12">
        <div class="text-center mb-10">
            <h2 class="text-3xl font-bold text-gray-800">Neden Medicare?</h2>
            <p class="text-gray-600 mt-2">Eczanenizi yönetmenin en güvenli ve hızlı yolu.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-8">
            <div class="bg-white p-6 rounded-xl shadow-lg border-t-4 border-blue-500 hover:shadow-2xl transition transform hover:-translate-y-2">
                <div class="w-14 h-14 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 text-blue-600">
                    <i class="fas fa-shield-alt text-2xl"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 text-center mb-2">Güvenli Veri</h3>
                <p class="text-gray-600 text-center text-sm">Tüm ilaç ve hasta verileriniz uçtan uca şifreleme ile güvende tutulur.</p>
            </div>

            <div class="bg-white p-6 rounded-xl shadow-lg border-t-4 border-green-500 hover:shadow-2xl transition transform hover:-translate-y-2">
                <div class="w-14 h-14 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 text-green-600">
                    <i class="fas fa-box-open text-2xl"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 text-center mb-2">Anlık Stok Takibi</h3>
                <p class="text-gray-600 text-center text-sm">İlaç giriş-çıkışlarını saniyesinde izleyin, stoklarınız asla tükenmesin.</p>
            </div>

            <div class="bg-white p-6 rounded-xl shadow-lg border-t-4 border-yellow-500 hover:shadow-2xl transition transform hover:-translate-y-2">
                <div class="w-14 h-14 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4 text-yellow-600">
                    <i class="fas fa-clock text-2xl"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 text-center mb-2">7/24 Erişim</h3>
                <p class="text-gray-600 text-center text-sm">Sisteme dilediğiniz yerden, dilediğiniz cihazdan kesintisiz erişim sağlayın.</p>
            </div>
        </div>
    </section>

    <footer class="bg-gray-800 text-white mt-12 py-8 text-center">
        <p class="text-lg">&copy; 2025 Medicare - Tüm Hakları Saklıdır.</p>
    </footer>

    <script src="a.js"></script>
</body>

</html>